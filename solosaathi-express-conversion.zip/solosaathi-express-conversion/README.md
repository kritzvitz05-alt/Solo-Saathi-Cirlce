# SoloSaathi Circle — Portable Express Server

This converts the backend off Netlify Functions specifically, onto a
standard, always-on Express server deployable on any normal Node hosting —
a VPS with PM2, Render, Railway, DigitalOcean App Platform, AWS EC2,
whatever a freelancer already knows how to run.

## What changed, and — importantly — what didn't

**Did not change**: every file in `netlify/functions/**` and
`netlify/shared/**` except `db.js`. The matching engine, OTP hard-block,
payment signature verification, refund flagging — all identical, all
still carrying the same test coverage described in earlier handoff notes.

**Did change**:
1. **`server.js`** (new) — a Express app that mounts every existing
   handler through one small adapter (`toExpressHandler`), translating a
   plain HTTP request into the same `{event}` shape those handlers already
   expect, and translating their `{statusCode, headers, body}` response
   back into a real HTTP response. Read the comments at the top of the
   file — they explain why the raw-body handling matters specifically for
   the payment webhook's signature verification.
2. **`db.js`** — the database driver, updated twice now:
   - First: from `@netlify/neon` (auto-reads `NETLIFY_DATABASE_URL`, only
     works inside Netlify's runtime) to `@neondatabase/serverless` (Neon's
     own generic driver).
   - **Then**: from `@neondatabase/serverless` to **`postgres`**
     (postgres.js) — because the Neon driver talks over Neon's own
     proprietary HTTP protocol, not the real Postgres wire protocol, so it
     only works against a Neon-hosted database. `postgres` is a standard
     client that works with **any** Postgres provider — Neon/Netlify DB,
     Supabase, Railway, Render, AWS RDS, or a self-hosted server —
     unchanged code, just point `DATABASE_URL` at whichever one you use.
   - All three drivers expose the same tagged-template `sql` query
     interface, so the other ~350 lines of `db.js` — every actual query —
     never needed to change across any of these swaps.
3. **Scheduled jobs** — Netlify Scheduled Functions only exist on
   serverless. On an always-on host, `node-cron` runs the same two jobs
   (`auto-finalize`, `flag-refund-candidates`) in-process, on the same
   schedule as before.

## There is no Claude/Anthropic dependency in this server

Worth saying plainly since it prompted this whole conversion: nothing here
runs on or requires Claude. The only place the Anthropic API is called
anywhere in this codebase is `ticket-verification/verify-ticket.js` — a
deliberate feature (reading ticket photos), unrelated to how or where the
server itself is hosted. It works identically here as it did before.

## Deploying this — literally any Node host

```bash
npm install
```

Set these environment variables (same ones as before, plus one new one):

| Variable | Notes |
|---|---|
| `DATABASE_URL` | Your Postgres connection string — from Netlify DB, Neon directly, Supabase, Railway, or any other Postgres provider. It's always a normal `postgres://...` string, and `db.js` works with any of them unchanged. |
| `ADMIN_SECRET`, `WHATSAPP_API_KEY`, `WHATSAPP_API_URL`, `ANTHROPIC_API_KEY`, `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`, `TICKET_TOKEN_SECRET` | Unchanged from before |
| `PORT` | Optional, defaults to 3000 |

```bash
npm start
```

That's the whole deployment. Point your frontend at whatever URL this ends
up running on, and update its API base path to match the routes below.

## Route map (this is new — Netlify Functions didn't expose clean paths like this)

| Method | Path | Was |
|---|---|---|
| POST | `/api/otp/send` | `otp/send-otp.js` |
| POST | `/api/otp/verify` | `otp/verify-otp.js` |
| POST | `/api/register/live` | `registration/register.js` |
| POST | `/api/register/advance` | `registration/advance-register.js` |
| POST | `/api/ticket/verify` | `ticket-verification/verify-ticket.js` |
| POST | `/api/circle/actions` | `circle/circle-actions.js` |
| POST | `/api/circle/finalize` | `circle/finalize-bucket.js` |
| GET/POST | `/api/circle/find-my-circle` | `circle/find-my-circle.js` |
| POST | `/api/organizer/auth` | `organizer/admin-auth.js` |
| GET | `/api/organizer/stats` | `organizer/organizer-stats.js` |
| POST | `/api/payments/create-order` | `payments/create-order.js` |
| POST | `/api/payments/verify` | `payments/verify-payment.js` |
| POST | `/api/payments/webhook` | `payments/webhook.js` — **update this URL in the Razorpay Dashboard webhook settings** |
| GET/POST | `/api/admin/refund-candidates` | `admin/refund-candidates.js` |
| GET | `/health` | new — basic uptime check |

## What's actually verified vs. what needs your own testing

**Verified, with real evidence, in this build**:
- All 17 routes register with zero broken `require()` paths
- A full request — built as Express would build it — was sent through the
  real adapter, into the real, unmodified `verify-payment.js`, correctly
  verified a real HMAC signature, and returned the correct response

**Not verified, and you should before trusting this in production**:
- **Could not install any npm package in the sandbox this was built in**
  (a package-installation restriction that appeared partway through this
  session, blocking even plain `express`) — so this was tested using
  minimal hand-written stubs standing in for Express, node-cron, and the
  Neon driver, not the real packages. The stubs were deliberately kept
  extremely simple (route registration and callback invocation only) so
  they'd only mask a real bug in an unlikely place — but "tested with a
  stub" and "tested with the real package" are different claims, and this
  needs a real `npm install` + `npm start` + a real request from a real
  client before it's trusted for launch.
- No real Postgres connection was tested — same caveat as the earlier
  `db.js` handoff.
