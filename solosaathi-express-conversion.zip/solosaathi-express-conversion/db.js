/**
 * @file netlify/shared/db.js
 * @description REAL IMPLEMENTATION — Netlify DB (Postgres, via Neon) persistence layer.
 *
 * This replaces the Phase 1 contract stub. Every function signature and
 * return shape below is UNCHANGED from the original contract in
 * docs/BACKEND_HANDOFF_LOG.md — per that document's own promise, no other
 * file in the backend needed to change for this to work.
 *
 * WHY POSTGRES INSTEAD OF NETLIFY BLOBS:
 * Netlify's own Blobs documentation explicitly warns against using Blobs
 * for "counters, balances, or read-modify-write logic ... even with
 * onlyIfMatch retries" and recommends Netlify DB instead for exactly this
 * kind of transactional data. Since the matching engine's group/pool state
 * is precisely that (a shared counter multiple concurrent requests can hit
 * at once), Postgres — with real transactions — is the correct choice.
 *
 * SETUP REQUIRED BEFORE THIS WORKS:
 *   1. `netlify db init` (provisions NETLIFY_DATABASE_URL automatically)
 *   2. Run netlify/shared/schema.sql once against that database
 *   3. `npm install @netlify/neon`
 *
 * KNOWN REMAINING GAP (flagged deliberately, not silently left):
 * getPendingPool/savePendingPool and getGroupState/saveGroupState are
 * implemented exactly per the original two-call (read, then write)
 * contract, for drop-in compatibility. That means the RACE CONDITION this
 * migration was meant to close still exists at the CALLING code's level
 * (register.js, advance-register.js, circle-actions.js) if two requests
 * read-modify-write concurrently, because those files still do two
 * separate calls rather than one atomic one.
 * Atomic, single-statement alternatives are provided below
 * (`atomicAppendToPool`, `atomicIncrementGroupState`) — the calling code
 * should be migrated to use these instead of get+save for true
 * concurrency-safety. This is the next concrete step, not done here, so
 * it doesn't get lost.
 */

/**
 * PORTABILITY NOTE (updated): originally `@netlify/neon`, then
 * `@neondatabase/serverless` — both work, but `@neondatabase/serverless`
 * specifically talks to the database over Neon's own proprietary HTTP
 * protocol, not the real Postgres wire protocol. That means it ONLY works
 * against a Neon-hosted database (via Netlify DB or Neon directly) — it
 * will not connect to Supabase, Railway, AWS RDS, or a self-hosted
 * Postgres. Swapped for `postgres` (postgres.js), a standard client
 * speaking the real wire protocol, so this now works with ANY Postgres
 * provider — including Neon/Netlify DB itself, unchanged. It supports the
 * same tagged-template `sql` syntax, so nothing below this line changed.
 */
const postgres = require('postgres');
const sql = postgres(process.env.DATABASE_URL || process.env.NETLIFY_DATABASE_URL);

// ---------------------------------------------------------------------
// Registrations
// ---------------------------------------------------------------------

async function getRegistration(id) {
  const rows = await sql`SELECT * FROM registrations WHERE id = ${id}`;
  if (rows.length === 0) return null;
  return rowToRegistration(rows[0]);
}

async function saveRegistration(id, registrationData) {
  const r = registrationData;
  await sql`
    INSERT INTO registrations (
      id, name, whatsapp, city, venue, gender, age_band, skill_level,
      all_women_toggle, captain_opt_in, ticket_serial, ticket_photo,
      verified_ticket, registration_type, event_date, payment_status,
      payment_id, circle_id, created_at, final_member_count, refund_status
    ) VALUES (
      ${id}, ${r.name}, ${r.whatsapp}, ${r.city}, ${r.venue}, ${r.gender},
      ${r.ageBand}, ${r.skillLevel}, ${r.allWomenToggle || false},
      ${r.captainOptIn || false}, ${r.ticketSerial || null}, ${r.ticketPhoto || null},
      ${r.verifiedTicket || false}, ${r.registrationType}, ${r.eventDate},
      ${r.paymentStatus || 'pending'}, ${r.paymentId || null},
      ${r.circleId || null}, ${r.createdAt || Date.now()},
      ${r.finalMemberCount === undefined ? null : r.finalMemberCount},
      ${r.refundStatus || 'none'}
    )
    ON CONFLICT (id) DO UPDATE SET
      name = EXCLUDED.name, whatsapp = EXCLUDED.whatsapp, city = EXCLUDED.city,
      venue = EXCLUDED.venue, gender = EXCLUDED.gender, age_band = EXCLUDED.age_band,
      skill_level = EXCLUDED.skill_level, all_women_toggle = EXCLUDED.all_women_toggle,
      captain_opt_in = EXCLUDED.captain_opt_in, ticket_serial = EXCLUDED.ticket_serial,
      ticket_photo = EXCLUDED.ticket_photo, verified_ticket = EXCLUDED.verified_ticket,
      registration_type = EXCLUDED.registration_type, event_date = EXCLUDED.event_date,
      payment_status = EXCLUDED.payment_status, payment_id = EXCLUDED.payment_id,
      circle_id = EXCLUDED.circle_id, final_member_count = EXCLUDED.final_member_count,
      refund_status = EXCLUDED.refund_status
  `;
  return r;
}

async function getRegistrationsByMobile(whatsapp, date) {
  const rows = await sql`
    SELECT id, circle_id, payment_status FROM registrations
    WHERE whatsapp = ${whatsapp} AND event_date = ${date}
  `;
  return rows.map((row) => ({
    id: row.id,
    circleId: row.circle_id,
    paymentStatus: row.payment_status,
  }));
}

function rowToRegistration(row) {
  return {
    id: row.id,
    name: row.name,
    whatsapp: row.whatsapp,
    city: row.city,
    venue: row.venue,
    gender: row.gender,
    ageBand: row.age_band,
    skillLevel: row.skill_level,
    allWomenToggle: row.all_women_toggle,
    captainOptIn: row.captain_opt_in,
    ticketSerial: row.ticket_serial,
    ticketPhoto: row.ticket_photo,
    verifiedTicket: row.verified_ticket,
    registrationType: row.registration_type,
    eventDate: row.event_date instanceof Date ? row.event_date.toISOString().slice(0, 10) : row.event_date,
    paymentStatus: row.payment_status,
    paymentId: row.payment_id,
    circleId: row.circle_id,
    createdAt: Number(row.created_at),
    finalMemberCount: row.final_member_count === null || row.final_member_count === undefined ? null : Number(row.final_member_count),
    refundStatus: row.refund_status || 'none',
  };
}

// ---------------------------------------------------------------------
// Pending pools (see KNOWN REMAINING GAP note above)
// ---------------------------------------------------------------------

async function getPendingPool(city, venue, level, genderPref, eventDate) {
  const rows = await sql`
    SELECT pool_data FROM pending_pools
    WHERE city = ${city} AND venue = ${venue} AND level = ${level}
      AND gender_pref = ${genderPref} AND event_date = ${eventDate}
  `;
  if (rows.length === 0) return [];
  return rows[0].pool_data;
}

async function savePendingPool(city, venue, level, genderPref, eventDate, poolArray) {
  await sql`
    INSERT INTO pending_pools (city, venue, level, gender_pref, event_date, pool_data)
    VALUES (${city}, ${venue}, ${level}, ${genderPref}, ${eventDate}, ${JSON.stringify(poolArray)}::jsonb)
    ON CONFLICT (city, venue, level, gender_pref, event_date)
    DO UPDATE SET pool_data = EXCLUDED.pool_data
  `;
  return poolArray;
}

// RECOMMENDED REPLACEMENT for the get+save pattern above — appends one
// entrant in a single atomic SQL statement, so two concurrent registration
// requests can never silently overwrite each other's write. Update
// advance-register.js to call this instead of getPendingPool+savePendingPool.
async function atomicAppendToPool(city, venue, level, genderPref, eventDate, entrant) {
  const rows = await sql`
    INSERT INTO pending_pools (city, venue, level, gender_pref, event_date, pool_data)
    VALUES (${city}, ${venue}, ${level}, ${genderPref}, ${eventDate}, ${JSON.stringify([entrant])}::jsonb)
    ON CONFLICT (city, venue, level, gender_pref, event_date)
    DO UPDATE SET pool_data = pending_pools.pool_data || ${JSON.stringify([entrant])}::jsonb
    RETURNING pool_data
  `;
  return rows[0].pool_data;
}

// ---------------------------------------------------------------------
// Group state (see KNOWN REMAINING GAP note above)
// ---------------------------------------------------------------------

async function getGroupState(city, venue, level, genderPref, date) {
  const rows = await sql`
    SELECT state_data FROM group_state
    WHERE city = ${city} AND venue = ${venue} AND level = ${level}
      AND gender_pref = ${genderPref} AND event_date = ${date}
  `;
  if (rows.length === 0) return null;
  return rows[0].state_data;
}

async function saveGroupState(city, venue, level, genderPref, date, stateObject) {
  await sql`
    INSERT INTO group_state (city, venue, level, gender_pref, event_date, state_data)
    VALUES (${city}, ${venue}, ${level}, ${genderPref}, ${date}, ${JSON.stringify(stateObject)}::jsonb)
    ON CONFLICT (city, venue, level, gender_pref, event_date)
    DO UPDATE SET state_data = EXCLUDED.state_data
  `;
  return stateObject;
}

// RECOMMENDED REPLACEMENT — atomically increments totalAttendeesMatched
// and appends a new circle ID if provided, in one statement. Update
// register.js's matching logic to use this instead of get+save for the
// counter itself.
async function atomicIncrementGroupState(city, venue, level, genderPref, date, options) {
  const incrementBy = options.incrementBy || 1;
  const newCircleId = options.newCircleId || null;
  const initial = JSON.stringify({
    activeCircleIds: newCircleId ? [newCircleId] : [],
    totalAttendeesMatched: incrementBy,
    lastCircleCounter: newCircleId ? 1 : 0,
    updatedAt: Date.now(),
  });
  const rows = await sql`
    INSERT INTO group_state (city, venue, level, gender_pref, event_date, state_data)
    VALUES (${city}, ${venue}, ${level}, ${genderPref}, ${date}, ${initial}::jsonb)
    ON CONFLICT (city, venue, level, gender_pref, event_date) DO UPDATE SET
      state_data = jsonb_set(
        jsonb_set(
          group_state.state_data,
          '{totalAttendeesMatched}',
          to_jsonb((group_state.state_data->>'totalAttendeesMatched')::int + ${incrementBy})
        ),
        '{updatedAt}',
        to_jsonb(${Date.now()}::bigint)
      ) || CASE WHEN ${newCircleId}::text IS NOT NULL THEN
        jsonb_build_object(
          'activeCircleIds', (group_state.state_data->'activeCircleIds') || to_jsonb(${newCircleId}::text),
          'lastCircleCounter', (group_state.state_data->>'lastCircleCounter')::int + 1
        )
      ELSE '{}'::jsonb END
    RETURNING state_data
  `;
  return rows[0].state_data;
}

// ---------------------------------------------------------------------
// Circle state
// ---------------------------------------------------------------------

async function getCircleState(circleId) {
  const rows = await sql`SELECT state_data FROM circle_state WHERE circle_id = ${circleId}`;
  if (rows.length === 0) return null;
  return rows[0].state_data;
}

async function saveCircleState(circleId, stateObject) {
  await sql`
    INSERT INTO circle_state (circle_id, state_data)
    VALUES (${circleId}, ${JSON.stringify(stateObject)}::jsonb)
    ON CONFLICT (circle_id) DO UPDATE SET state_data = EXCLUDED.state_data
  `;
  return stateObject;
}

// ---------------------------------------------------------------------
// Showups (venue-scoped, no date — matches the documented signature)
// ---------------------------------------------------------------------

async function getShowups(city, venue) {
  const rows = await sql`SELECT showups_data FROM showups WHERE city = ${city} AND venue = ${venue}`;
  if (rows.length === 0) return [];
  return rows[0].showups_data;
}

async function saveShowups(city, venue, showupsArray) {
  await sql`
    INSERT INTO showups (city, venue, showups_data)
    VALUES (${city}, ${venue}, ${JSON.stringify(showupsArray)}::jsonb)
    ON CONFLICT (city, venue) DO UPDATE SET showups_data = EXCLUDED.showups_data
  `;
  return showupsArray;
}

// ---------------------------------------------------------------------
// OTP records
// ---------------------------------------------------------------------

async function getOtpRecord(whatsapp) {
  const rows = await sql`SELECT code, expires_at, attempts, created_at FROM otp_records WHERE whatsapp = ${whatsapp}`;
  if (rows.length === 0) return null;
  const row = rows[0];
  if (Number(row.expires_at) < Date.now()) return null; // expired, treat as absent
  return { code: row.code, expiresAt: Number(row.expires_at), attempts: row.attempts, createdAt: Number(row.created_at) };
}

async function saveOtpRecord(whatsapp, otpData) {
  await sql`
    INSERT INTO otp_records (whatsapp, code, expires_at, attempts, created_at)
    VALUES (${whatsapp}, ${otpData.code}, ${otpData.expiresAt}, ${otpData.attempts || 0}, ${otpData.createdAt || Date.now()})
    ON CONFLICT (whatsapp) DO UPDATE SET
      code = EXCLUDED.code, expires_at = EXCLUDED.expires_at,
      attempts = EXCLUDED.attempts, created_at = EXCLUDED.created_at
  `;
  return otpData;
}

// ---------------------------------------------------------------------
// OTP rate limiting
// ---------------------------------------------------------------------

async function getOtpRateLimit(whatsapp) {
  const rows = await sql`SELECT count, window_start_time, last_sent_at FROM otp_rate_limits WHERE whatsapp = ${whatsapp}`;
  if (rows.length === 0) return null;
  const row = rows[0];
  return { count: row.count, windowStartTime: Number(row.window_start_time), lastSentAt: Number(row.last_sent_at) };
}

async function saveOtpRateLimit(whatsapp, rateLimitData) {
  await sql`
    INSERT INTO otp_rate_limits (whatsapp, count, window_start_time, last_sent_at)
    VALUES (${whatsapp}, ${rateLimitData.count}, ${rateLimitData.windowStartTime}, ${rateLimitData.lastSentAt || 0})
    ON CONFLICT (whatsapp) DO UPDATE SET
      count = EXCLUDED.count, window_start_time = EXCLUDED.window_start_time,
      last_sent_at = EXCLUDED.last_sent_at
  `;
  return rateLimitData;
}

// ---------------------------------------------------------------------
// Verified status
// ---------------------------------------------------------------------

async function getVerifiedStatus(whatsapp) {
  const rows = await sql`SELECT verified_at, expires_at FROM verified_status WHERE whatsapp = ${whatsapp}`;
  if (rows.length === 0) return null;
  const row = rows[0];
  if (Number(row.expires_at) < Date.now()) return null; // expired
  return { verified: true, verifiedAt: Number(row.verified_at), expiresAt: Number(row.expires_at) };
}

async function saveVerifiedStatus(whatsapp, timestamp) {
  const expiresAt = timestamp + 30 * 60 * 1000; // 30-minute verified TTL, per spec
  await sql`
    INSERT INTO verified_status (whatsapp, verified_at, expires_at)
    VALUES (${whatsapp}, ${timestamp}, ${expiresAt})
    ON CONFLICT (whatsapp) DO UPDATE SET verified_at = EXCLUDED.verified_at, expires_at = EXCLUDED.expires_at
  `;
  return { verified: true, verifiedAt: timestamp, expiresAt };
}

// ---------------------------------------------------------------------
// Venues
// ---------------------------------------------------------------------

async function getVenues() {
  const rows = await sql`SELECT city, venues_data FROM venues_config`;
  const result = {};
  for (const row of rows) {
    result[row.city] = row.venues_data;
  }
  return result;
}

// NEW — supports the nightly refund-flagging job (see
// scheduled/flag-refund-candidates.js). Returns every registration for a
// given event date, so the job can group them by circle and snapshot each
// circle's final size onto its members before that night's data ages out.
async function getRegistrationsForDate(eventDate) {
  const rows = await sql`SELECT * FROM registrations WHERE event_date = ${eventDate}`;
  return rows.map(rowToRegistration);
}

// NEW — powers the manual refund review endpoint. Only ever set by the
// nightly job, never by an attendee-facing flow, and never advertised —
// see HANDOFF_NOTES for why this is deliberately not in the Terms &
// Conditions or automated.
async function getRefundCandidates() {
  const rows = await sql`SELECT * FROM registrations WHERE refund_status = 'flagged' ORDER BY event_date DESC`;
  return rows.map(rowToRegistration);
}

// NEW — marks a candidate as handled once you've actually processed the
// refund in the Razorpay dashboard, so it stops showing up in the review
// list on the next run.
async function markRefundProcessed(id) {
  await sql`UPDATE registrations SET refund_status = 'refunded' WHERE id = ${id}`;
  return { id, refundStatus: 'refunded' };
}

module.exports = {
  getRegistration,
  saveRegistration,
  getRegistrationsByMobile,
  getRegistrationsForDate,
  getRefundCandidates,
  markRefundProcessed,
  getPendingPool,
  savePendingPool,
  atomicAppendToPool,
  getGroupState,
  saveGroupState,
  atomicIncrementGroupState,
  getCircleState,
  saveCircleState,
  getShowups,
  saveShowups,
  getOtpRecord,
  saveOtpRecord,
  getOtpRateLimit,
  saveOtpRateLimit,
  getVerifiedStatus,
  saveVerifiedStatus,
  getVenues,
};
