/**
 * @file server.js
 * @description Standard, portable HTTPS server for SoloSaathi Circle —
 * deployable on ANY normal Node.js hosting (a VPS with PM2, Render,
 * Railway, DigitalOcean App Platform, AWS EC2, etc.), not tied to Netlify.
 *
 * IMPORTANT — WHAT THIS DOES AND DOES NOT CHANGE:
 * Every route below mounts the EXACT SAME handler files already built and
 * tested (netlify/functions/**). Not one line of business logic — the
 * matching engine, OTP hard-block, payment verification, refund flagging —
 * was rewritten. Only the adapter layer connecting a plain HTTP request to
 * those handlers changed, because Netlify's serverless handler signature
 * ({event} in, {statusCode, headers, body} out) needed a thin translation
 * to Express's (req, res) signature. See `toExpressHandler()` below — it's
 * the one piece of new "how requests get in" code; everything after it
 * that a request touches is unchanged.
 *
 * THERE IS NO DEPENDENCY ON CLAUDE OR ANTHROPIC IN THIS SERVER ITSELF.
 * The only place Claude's API is called anywhere in this codebase is
 * ticket-verification/verify-ticket.js — a deliberate product feature
 * (reading ticket photos), not an infrastructure requirement. It works
 * identically on this server as it did on Netlify Functions.
 *
 * DATABASE: still Netlify DB (Postgres, via Neon) — that database is a
 * real, standard Postgres instance reachable from anywhere via a normal
 * connection string. It is NOT locked to Netlify hosting. See db.js for
 * the one small change that made this portable (swapping the
 * Netlify-specific env-var auto-read for a plain DATABASE_URL).
 */

const express = require('express');
const cron = require('node-cron');

const app = express();

// Raw body as a string, regardless of content-type — this matters, not
// just a style choice. Netlify's `event.body` is always a raw string, and
// webhook.js's HMAC signature verification specifically needs the exact
// raw bytes Razorpay signed. Using express.json() here would re-serialize
// the body before handlers see it, silently breaking that verification.
app.use(express.text({ type: '*/*', limit: '5mb' }));

/**
 * Wraps a Netlify-style handler module so it can be mounted as a normal
 * Express route, with zero changes to the handler itself.
 */
function toExpressHandler(handlerModule) {
  return async (req, res) => {
    const event = {
      httpMethod: req.method,
      headers: req.headers, // Node already lowercases header names, matching Netlify's behavior
      body: typeof req.body === 'string' && req.body.length > 0 ? req.body : null,
      queryStringParameters: req.query,
      isBase64Encoded: false,
    };
    try {
      const result = await handlerModule.handler(event, {});
      res.status(result.statusCode || 200);
      if (result.headers) {
        for (const key of Object.keys(result.headers)) {
          res.set(key, result.headers[key]);
        }
      }
      res.send(result.body);
    } catch (error) {
      console.error(`[server] Unhandled error in ${req.method} ${req.path}:`, error);
      res.status(500).json({ success: false, error: 'Internal server error' });
    }
  };
}

// Handle CORS preflight globally, matching handleOptions() in shared/response.js
app.options('*', (req, res) => {
  res.set('Access-Control-Allow-Origin', '*');
  res.set('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
  res.set('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  res.status(204).send('');
});

// ---------------------------------------------------------------------
// Routes — one line each, every one backed by an already-tested handler
// ---------------------------------------------------------------------
function mount(method, path, handler) {
  app[method](path, toExpressHandler(handler));
}

mount('post', '/api/otp/send', require('./netlify/functions/otp/send-otp'));
mount('post', '/api/otp/verify', require('./netlify/functions/otp/verify-otp'));
mount('post', '/api/register/live', require('./netlify/functions/registration/register'));
mount('post', '/api/register/advance', require('./netlify/functions/registration/advance-register'));
mount('post', '/api/ticket/verify', require('./netlify/functions/ticket-verification/verify-ticket'));
mount('post', '/api/circle/actions', require('./netlify/functions/circle/circle-actions'));
mount('post', '/api/circle/finalize', require('./netlify/functions/circle/finalize-bucket'));
app.get('/api/circle/find-my-circle', toExpressHandler(require('./netlify/functions/circle/find-my-circle')));
app.post('/api/circle/find-my-circle', toExpressHandler(require('./netlify/functions/circle/find-my-circle')));
mount('post', '/api/organizer/auth', require('./netlify/functions/organizer/admin-auth'));
app.get('/api/organizer/stats', toExpressHandler(require('./netlify/functions/organizer/organizer-stats')));
mount('post', '/api/payments/create-order', require('./netlify/functions/payments/create-order'));
mount('post', '/api/payments/verify', require('./netlify/functions/payments/verify-payment'));
mount('post', '/api/payments/webhook', require('./netlify/functions/payments/webhook'));
app.get('/api/admin/refund-candidates', toExpressHandler(require('./netlify/functions/admin/refund-candidates')));
app.post('/api/admin/refund-candidates', toExpressHandler(require('./netlify/functions/admin/refund-candidates')));

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'solosaathi-backend' }));

// ---------------------------------------------------------------------
// Scheduled jobs — these ran as Netlify Scheduled Functions (which only
// exist on serverless). On an always-on host, a normal in-process cron
// library does the same job with no external dependency.
// ---------------------------------------------------------------------
const autoFinalize = require('./netlify/functions/scheduled/auto-finalize');
const flagRefundCandidates = require('./netlify/functions/scheduled/flag-refund-candidates');

cron.schedule('0 * * * *', async () => {
  console.log('[cron] Running auto-finalize...');
  try {
    await autoFinalize.handler({});
  } catch (error) {
    console.error('[cron] auto-finalize failed:', error);
  }
});

cron.schedule('45 19 * * *', async () => {
  console.log('[cron] Running flag-refund-candidates...');
  try {
    await flagRefundCandidates.handler();
  } catch (error) {
    console.error('[cron] flag-refund-candidates failed:', error);
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`SoloSaathi Circle backend running on port ${PORT}`);
  console.log('Scheduled jobs active: auto-finalize (@hourly), flag-refund-candidates (1:15 AM IST daily)');
});

module.exports = app;
